﻿
namespace $safeprojectname$.Handlers.Articles
{
    public class ArticleBaseModel
    {
        public string Title { get; set; }
    }
}
