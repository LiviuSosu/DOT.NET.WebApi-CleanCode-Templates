﻿using System.Collections.Generic;

namespace $safeprojectname$.Handlers.Articles.Queries.GetArticles
{
    public class ArticlesListViewModel
    {
        public IList<ArticleLookupModel> Articles { get; set; }
    }
}
