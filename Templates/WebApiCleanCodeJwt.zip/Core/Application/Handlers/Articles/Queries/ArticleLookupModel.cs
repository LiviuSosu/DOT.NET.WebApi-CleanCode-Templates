﻿using System;

namespace $safeprojectname$.Handlers.Articles.Queries
{
    public class ArticleLookupModel : ArticleBaseModel
    {
        public Guid Id { get; set; }
    }
}
