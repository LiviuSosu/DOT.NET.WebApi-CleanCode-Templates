﻿using MediatR;

namespace $safeprojectname$.Handlers.Articles.Commands.Create
{
    public class CreateArticleCommand : ArticleBaseModel, IRequest
    {
    }
}
