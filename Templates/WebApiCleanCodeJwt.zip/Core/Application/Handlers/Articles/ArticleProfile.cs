﻿using $safeprojectname$.Handlers.Articles.Commands.Create;
using $safeprojectname$.Handlers.Articles.Commands.Delete;
using $safeprojectname$.Handlers.Articles.Commands.Update;
using $safeprojectname$.Handlers.Articles.Queries;
using AutoMapper;
using Domain.Entities;

namespace $safeprojectname$.Handlers.Articles
{
    public class ArticleProfile : Profile
    {
        public ArticleProfile()
        {
            CreateMap<Article, ArticleLookupModel>();
            CreateMap<CreateArticleCommand, Article>();
            CreateMap<UpdateArticleCommand, Article>();
            CreateMap<DeleteArticleCommand, Article>();
        }
    }
}
