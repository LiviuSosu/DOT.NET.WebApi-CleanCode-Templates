﻿using FluentValidation;

namespace $safeprojectname$.Handlers
{
    public class BaseValidator<T> : AbstractValidator<T>
    {
    }
}
