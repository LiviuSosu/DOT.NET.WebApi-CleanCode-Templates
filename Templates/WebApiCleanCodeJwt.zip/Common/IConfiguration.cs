﻿
namespace $safeprojectname$
{
    public interface IConfiguration
    {
        string ErrorMessage { get; }
        string DisplayObjectNotFoundErrorMessage { get; }
    }
}
