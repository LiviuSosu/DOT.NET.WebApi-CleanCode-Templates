﻿using Domain.Entities;

namespace $safeprojectname$.Repository.ArticleRepository
{
    public interface IArticleRepository : IRepositoryBase<Article>
    {
    }
}
