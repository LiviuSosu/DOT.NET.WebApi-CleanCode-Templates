﻿using Domain.Entities;

namespace $safeprojectname$.Repository.ArticleRepository
{
    public class ArticleRepository : RepositoryBase<Article>, IArticleRepository
    {
        public ArticleRepository(AppDatabaseContext careerTrackDbContext)
        : base(careerTrackDbContext)
        {
        }
    }
}
