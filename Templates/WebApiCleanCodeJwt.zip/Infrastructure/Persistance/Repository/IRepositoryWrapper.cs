﻿using $safeprojectname$.Repository.ArticleRepository;
using System.Threading.Tasks;

namespace $safeprojectname$.Repository
{
    public interface IRepositoryWrapper
    {
        IArticleRepository Article { get; }

        Task SaveAsync();
    }
}
